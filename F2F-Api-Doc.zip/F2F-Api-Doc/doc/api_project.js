define({
  "name": "F2F Core API",
  "version": "1.0.0",
  "description": "This document covers all the request and response of F2F Core API. It also covers blah blah ....",
  "title": "F2F Core API",
  "url": "https://api.f2f.io",
  "template": {
    "withCompare": true,
    "withGenerator": true
  },
  "sampleUrl": false,
  "apidoc": "0.2.0",
  "generator": {
    "name": "apidoc",
    "time": "2016-06-22T15:27:35.669Z",
    "url": "http://apidocjs.com",
    "version": "0.12.3"
  }
});